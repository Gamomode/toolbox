(function () {
  window.UX = {
    声明: '本组件为应用自带用户体验模块，随打包自动加入，含声明与体验记录。',
    体验: {
      版本: '1.0',
      首次打开: true,
      记录: [],
      提示: function (msg) { this.记录.push({ 内容: msg, 时间: Date.now() }); }
    }
  };
})();