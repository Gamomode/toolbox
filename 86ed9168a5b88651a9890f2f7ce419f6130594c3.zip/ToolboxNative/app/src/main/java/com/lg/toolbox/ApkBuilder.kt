package com.lg.toolbox

import android.content.Context
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.KeyFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Calendar
import java.util.zip.Deflater

class ApkOptions(
    val label: String,
    val pkg: String,
    val versionName: String = "1.0",
    val versionCode: Int = 1,
    val fullscreen: Boolean = false,
    val orientation: Int = -1,
    val icon: ByteArray? = null,
    val permissions: List<String> = emptyList(),
    val deep: String? = null
)

class ApkEntry(val name: String, val data: ByteArray, var method: Int, val align: Int = 0) {
    var payload: ByteArray? = null
}

object ApkBuilder {

    const val DEFAULT_LABEL = "网页应用"
    const val DEFAULT_PKG = "com.armorlab.app"

    private const val UTF8_FLAG = 0x100
    private const val SORTED_FLAG = 0x1

    private lateinit var T: Map<String, ByteArray>

    fun init(ctx: Context) {
        if (::T.isInitialized) return
        val m = mutableMapOf<String, ByteArray>()
        val names = listOf(
            "manifest_normal", "manifest_fs", "resources.arsc",
            "classes_normal.dex", "classes_fs.dex", "classes_plain.dex", "classes_plain_fs.dex",
            "classes_adv.dex", "classes_adv_fs.dex",
            "icon.png", "ux.js", "cert.der", "key.pkcs8", "issuer.der", "serial.der"
        )
        for (n in names) {
            ctx.assets.open("pack/$n").use { m[n] = it.readBytes() }
        }
        T = m
    }

    private fun rU16(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)

    private fun rU32(b: ByteArray, o: Int): Long =
        (rU16(b, o) or (rU16(b, o + 2) shl 16)).toLong() and 0xFFFFFFFFL

    private fun wU16(b: ByteArray, o: Int, n: Int) {
        b[o] = (n and 0xFF).toByte()
        b[o + 1] = ((n shr 8) and 0xFF).toByte()
    }

    private fun wU32(b: ByteArray, o: Int, n: Long) {
        for (i in 0..3) b[o + i] = ((n shr (8 * i)) and 0xFF).toByte()
    }

    private fun concat(parts: List<ByteArray>): ByteArray {
        var n = 0
        for (p in parts) n += p.size
        val out = ByteArray(n)
        var o = 0
        for (p in parts) {
            System.arraycopy(p, 0, out, o, p.size)
            o += p.size
        }
        return out
    }

    private fun u16b(n: Int): ByteArray = byteArrayOf((n and 0xFF).toByte(), ((n shr 8) and 0xFF).toByte())

    private fun u32b(n: Long): ByteArray = ByteArray(4).also { wU32(it, 0, n) }

    private fun align4(n: Int): Int = (n + 3) and 3.inv()

    private fun readLen8(b: ByteArray, off: Int): Pair<Int, Int> {
        val v = b[off].toInt() and 0xFF
        return if (v and 0x80 != 0) {
            (((v and 0x7F) shl 8) or (b[off + 1].toInt() and 0xFF)) to 2
        } else v to 1
    }

    private fun decodePoolString(b: ByteArray, off: Int, isUtf8: Boolean): Pair<String, Int> {
        if (isUtf8) {
            val l1 = readLen8(b, off)
            val l2 = readLen8(b, off + l1.second)
            val start = off + l1.second + l2.second
            return String(b, start, l2.first, Charsets.UTF_8) to (start + l2.second - off)
        }
        val units = rU16(b, off)
        val start = off + 2
        val sb = StringBuilder()
        for (i in 0 until units) sb.append(rU16(b, start + i * 2).toChar())
        return sb.toString() to (2 + units * 2)
    }

    private fun encLen8(n: Int): ByteArray =
        if (n < 0x80) byteArrayOf(n.toByte())
        else byteArrayOf((0x80 or (n shr 8)).toByte(), (n and 0xFF).toByte())

    private fun encodePoolString(text: String, isUtf8: Boolean): ByteArray {
        if (isUtf8) {
            val data = text.toByteArray(Charsets.UTF_8)
            return concat(listOf(encLen8(text.length), encLen8(data.size), data, byteArrayOf(0)))
        }
        val out = ByteArray(4 + text.length * 2)
        wU16(out, 0, text.length)
        for (i in text.indices) wU16(out, 2 + i * 2, text[i].code)
        wU16(out, 2 + text.length * 2, 0)
        return out
    }

    private fun rebuildStringPool(old: ByteArray, replacements: List<Pair<String, String>>): ByteArray {
        val stringCount = rU32(old, 8).toInt()
        val styleCount = rU32(old, 12).toInt()
        val oldFlags = rU32(old, 16)
        val stringsStart = rU32(old, 20).toInt()
        val isUtf8 = (oldFlags and UTF8_FLAG.toLong()) != 0L
        val texts = (0 until stringCount).map {
            decodePoolString(old, stringsStart + rU32(old, 28 + it * 4).toInt(), isUtf8).first
        }
        val outTexts = texts.map { t ->
            for (r in replacements) if (t == r.first) return@map r.second
            t
        }
        val offsets = mutableListOf<Int>()
        val datas = mutableListOf<ByteArray>()
        var cur = 0
        for (t in outTexts) {
            val enc = encodePoolString(t, isUtf8)
            offsets.add(cur)
            datas.add(enc)
            cur += align4(enc.size)
        }
        val flags = oldFlags and SORTED_FLAG.inv()
        val offsetsSize = stringCount * 4
        val size = 28 + offsetsSize + cur
        val out = ByteArray(size)
        wU16(out, 0, 1)
        wU16(out, 2, 28)
        wU32(out, 4, size.toLong())
        wU32(out, 8, stringCount.toLong())
        wU32(out, 12, styleCount.toLong())
        wU32(out, 16, flags)
        wU32(out, 20, (28 + offsetsSize).toLong())
        wU32(out, 24, 0L)
        var o = 28
        for (off in offsets) {
            wU32(out, o, off.toLong())
            o += 4
        }
        for (d in datas) {
            System.arraycopy(d, 0, out, o, d.size)
            o = align4(o + d.size)
        }
        return out
    }

    private fun readPoolStrings(xml: ByteArray): List<String> {
        var pos = rU16(xml, 2)
        while (pos + 8 <= xml.size) {
            val type = rU16(xml, pos)
            val cs = rU32(xml, pos + 4).toInt()
            if (type == 1) {
                val stringCount = rU32(xml, pos + 8).toInt()
                val isUtf8 = (rU32(xml, pos + 16) and UTF8_FLAG.toLong()) != 0L
                val stringsStart = pos + rU32(xml, pos + 20).toInt()
                val out = mutableListOf<String>()
                for (i in 0 until stringCount) {
                    out.add(decodePoolString(xml, stringsStart + rU32(xml, pos + 28 + i * 4).toInt(), isUtf8).first)
                }
                return out
            }
            if (cs == 0) break
            pos += cs
        }
        return emptyList()
    }

    fun patchBinaryXml(xml: ByteArray, replacements: List<Pair<String, String>>): ByteArray {
        var pos = rU16(xml, 2)
        while (pos + 8 <= xml.size) {
            val type = rU16(xml, pos)
            val cs = rU32(xml, pos + 4).toInt()
            if (type == 1) {
                val oldChunk = xml.copyOfRange(pos, pos + cs)
                val rebuilt = rebuildStringPool(oldChunk, replacements)
                val out: ByteArray = if (rebuilt.size != oldChunk.size) {
                    val o = ByteArray(xml.size - oldChunk.size + rebuilt.size)
                    System.arraycopy(xml, 0, o, 0, pos)
                    System.arraycopy(rebuilt, 0, o, pos, rebuilt.size)
                    System.arraycopy(xml, pos + cs, o, pos + rebuilt.size, xml.size - pos - cs)
                    o
                } else {
                    val o = xml.copyOf()
                    System.arraycopy(rebuilt, 0, o, pos, rebuilt.size)
                    o
                }
                wU32(out, 4, out.size.toLong())
                return out
            }
            if (cs == 0) break
            pos += cs
        }
        return xml
    }

    fun patchArscPackageName(arsc: ByteArray, oldPkg: String, newPkg: String): ByteArray {
        val oldUnits = oldPkg.map { it.code }
        val limit = minOf(arsc.size - oldUnits.size * 2, 2048)
        var o = 0
        while (o <= limit) {
            var ok = true
            for (i in oldUnits.indices) {
                if ((arsc[o + i * 2].toInt() and 0xFF) != (oldUnits[i] and 0xFF) || (arsc[o + i * 2 + 1].toInt() and 0xFF) != (oldUnits[i] shr 8)) {
                    ok = false
                    break
                }
            }
            if (ok) {
                val out = arsc.copyOf()
                for (i in newPkg.indices) wU16(out, o + i * 2, newPkg[i].code)
                for (i in newPkg.length until oldUnits.size) wU16(out, o + i * 2, 0)
                return out
            }
            o++
        }
        return arsc
    }

    fun patchManifestVersionCode(xml: ByteArray, code: Int): ByteArray {
        val names = readPoolStrings(xml)
        val idx = names.indexOf("versionCode")
        if (idx < 0) return xml
        val out = xml.copyOf()
        var pos = rU16(xml, 2)
        while (pos + 8 <= xml.size) {
            val type = rU16(xml, pos)
            val cs = rU32(xml, pos + 4).toInt()
            if (type == 258) {
                val attrCount = rU32(xml, pos + 28).toInt()
                for (i in 0 until attrCount) {
                    val a = pos + 36 + i * 20
                    if (rU32(out, a + 4) == idx.toLong()) wU32(out, a + 16, code.toLong())
                }
            }
            if (cs == 0) break
            pos += cs
        }
        return out
    }

    fun addManifestPermissions(xml: ByteArray, perms: List<String>): ByteArray {
        var poolPos = -1
        var poolLen = 0
        var nodeStart = -1
        run {
            var pos = rU16(xml, 2)
            while (pos + 8 <= xml.size) {
                val type = rU16(xml, pos)
                val cs = rU32(xml, pos + 4).toInt()
                if (type == 1) {
                    poolPos = pos
                    poolLen = cs
                } else if (type != 384) {
                    nodeStart = pos
                    break
                }
                if (cs == 0) break
                pos += cs
            }
        }
        if (poolPos < 0 || nodeStart < 0) return xml
        val oldPool = xml.copyOfRange(poolPos, poolPos + poolLen)
        val stringCount = rU32(oldPool, 8).toInt()
        val styleCount = rU32(oldPool, 12).toInt()
        val isUtf8 = (rU32(oldPool, 16) and UTF8_FLAG.toLong()) != 0L
        val stringsStart = rU32(oldPool, 20).toInt()
        val texts = (0 until stringCount).map {
            decodePoolString(oldPool, stringsStart + rU32(oldPool, 28 + it * 4).toInt(), isUtf8).first
        }
        val styleTail = if (styleCount > 0) oldPool.copyOfRange(rU32(oldPool, 24).toInt(), oldPool.size) else null
        val NS = "http://schemas.android.com/apk/res/android"
        val appends = mutableListOf<String>()
        fun idxOf(s: String, ensure: Boolean): Int {
            val i = texts.indexOf(s)
            if (i >= 0 || !ensure) return i
            appends.add(s)
            return stringCount + appends.size - 1
        }
        val nsIdx = idxOf(NS, true)
        val nameIdx = idxOf("name", true)
        val upIdx = idxOf("uses-permission", true)
        val appIdx = idxOf("application", true)
        val permIdx = mutableListOf<Int>()
        for (p in perms) {
            if (texts.contains(p)) continue
            permIdx.add(idxOf(p, true))
        }
        if (permIdx.isEmpty()) return xml
        val allTexts = texts + appends
        val offsets = mutableListOf<Int>()
        val datas = mutableListOf<ByteArray>()
        var cur = 0
        for (t in allTexts) {
            val enc = encodePoolString(t, isUtf8)
            offsets.add(cur)
            datas.add(enc)
            cur += align4(enc.size)
        }
        val offCount = allTexts.size * 4
        var styleData: ByteArray? = null
        if (styleTail != null) {
            val baseLen = 28 + offCount + cur
            val pad = (4 - baseLen % 4) % 4
            val sd = ByteArray(pad + styleTail.size)
            System.arraycopy(styleTail, 0, sd, pad, styleTail.size)
            cur += pad
            styleData = sd
        }
        val poolSize = 28 + offCount + cur
        val newPool = ByteArray(poolSize)
        wU16(newPool, 0, 1)
        wU16(newPool, 2, 28)
        wU32(newPool, 4, poolSize.toLong())
        wU32(newPool, 8, allTexts.size.toLong())
        wU32(newPool, 12, styleCount.toLong())
        wU32(newPool, 16, rU32(oldPool, 16) and SORTED_FLAG.inv().toLong())
        wU32(newPool, 20, (28 + offCount).toLong())
        wU32(newPool, 24, if (styleData != null) (28 + offCount + (cur - styleData.size)).toLong() else 0L)
        var o = 28
        for (off in offsets) {
            wU32(newPool, o, off.toLong())
            o += 4
        }
        for (d in datas) {
            System.arraycopy(d, 0, newPool, o, d.size)
            o += align4(d.size)
        }
        if (styleData != null) System.arraycopy(styleData, 0, newPool, o, styleData.size)
        val tree = xml.copyOfRange(poolPos + poolLen, xml.size)
        var appOff = -1
        var p = 0
        while (p + 8 <= tree.size) {
            if (rU16(tree, p) == 258 && rU32(tree, p + 20) == appIdx.toLong()) {
                appOff = p
                break
            }
            p += 4
        }
        if (appOff < 0) return xml
        val nodes = mutableListOf<ByteArray>()
        for (pi in permIdx) {
            val start = ByteArray(56)
            wU16(start, 0, 258)
            wU16(start, 2, 16)
            wU32(start, 4, 56)
            wU32(start, 8, 1)
            wU32(start, 12, 4294967295L)
            wU32(start, 16, nsIdx.toLong())
            wU32(start, 20, upIdx.toLong())
            wU16(start, 24, 20)
            wU16(start, 26, 20)
            wU16(start, 28, 1)
            wU16(start, 30, 0)
            wU16(start, 32, 0)
            wU16(start, 34, 0)
            wU32(start, 36, nsIdx.toLong())
            wU32(start, 40, nameIdx.toLong())
            wU32(start, 44, pi.toLong())
            wU16(start, 48, 8)
            start[50] = 0
            start[51] = 3
            wU32(start, 52, pi.toLong())
            val end = ByteArray(24)
            wU16(end, 0, 259)
            wU16(end, 2, 16)
            wU32(end, 4, 24)
            wU32(end, 8, 1)
            wU32(end, 12, 4294967295L)
            wU32(end, 16, nsIdx.toLong())
            wU32(end, 20, upIdx.toLong())
            nodes.add(start)
            nodes.add(end)
        }
        val nodesLen = nodes.sumOf { it.size }
        val out = ByteArray(poolPos + newPool.size + tree.size + nodesLen)
        System.arraycopy(xml, 0, out, 0, poolPos)
        System.arraycopy(newPool, 0, out, poolPos, newPool.size)
        val treeOutPos = poolPos + newPool.size
        System.arraycopy(tree, 0, out, treeOutPos, appOff)
        var np = treeOutPos + appOff
        for (n in nodes) {
            System.arraycopy(n, 0, out, np, n.size)
            np += n.size
        }
        System.arraycopy(tree, appOff, out, np, tree.size - appOff)
        wU32(out, 4, out.size.toLong())
        return out
    }

    fun addScreenOrientation(xmlIn: ByteArray, value: Int): ByteArray {
        var xml = xmlIn
        val v = if (value == 0 || value == 1) value else -1
        var poolPos = -1
        var poolLen = 0
        var mapPos = -1
        var mapLen = 0
        run {
            var pos = rU16(xml, 2)
            while (pos + 8 <= xml.size) {
                val type = rU16(xml, pos)
                val cs = rU32(xml, pos + 4).toInt()
                if (type == 1) {
                    poolPos = pos
                    poolLen = cs
                } else if (type == 384) {
                    mapPos = pos
                    mapLen = cs
                }
                if (cs == 0) break
                pos += cs
            }
        }
        if (poolPos < 0 || v < 0) return xml
        val oldPool = xml.copyOfRange(poolPos, poolPos + poolLen)
        val stringCount = rU32(oldPool, 8).toInt()
        val styleCount = rU32(oldPool, 12).toInt()
        val isUtf8 = (rU32(oldPool, 16) and UTF8_FLAG.toLong()) != 0L
        val stringsStart = rU32(oldPool, 20).toInt()
        val texts = (0 until stringCount).map {
            decodePoolString(oldPool, stringsStart + rU32(oldPool, 28 + it * 4).toInt(), isUtf8).first
        }
        val NS = "http://schemas.android.com/apk/res/android"
        val nsIdx = texts.indexOf(NS)
        val actIdx = texts.indexOf("activity")
        if (nsIdx < 0 || actIdx < 0) return xml
        var soIdx = texts.indexOf("screenOrientation")
        var newPool = oldPool
        if (soIdx < 0) {
            soIdx = stringCount
            val styleTail = if (styleCount > 0) oldPool.copyOfRange(rU32(oldPool, 24).toInt(), oldPool.size) else null
            val allTexts = texts + listOf("screenOrientation")
            val offsets = mutableListOf<Int>()
            val datas = mutableListOf<ByteArray>()
            var cur = 0
            for (t in allTexts) {
                val enc = encodePoolString(t, isUtf8)
                offsets.add(cur)
                datas.add(enc)
                cur += align4(enc.size)
            }
            var styleData: ByteArray? = null
            if (styleTail != null) {
                val baseLen = 28 + allTexts.size * 4 + cur
                val pad = (4 - baseLen % 4) % 4
                val sd = ByteArray(pad + styleTail.size)
                System.arraycopy(styleTail, 0, sd, pad, styleTail.size)
                cur += pad
                styleData = sd
            }
            val poolSize = 28 + allTexts.size * 4 + cur
            newPool = ByteArray(poolSize)
            wU16(newPool, 0, 1)
            wU16(newPool, 2, 28)
            wU32(newPool, 4, poolSize.toLong())
            wU32(newPool, 8, allTexts.size.toLong())
            wU32(newPool, 12, styleCount.toLong())
            wU32(newPool, 16, rU32(oldPool, 16) and SORTED_FLAG.inv().toLong())
            wU32(newPool, 20, (28 + allTexts.size * 4).toLong())
            wU32(newPool, 24, if (styleData != null) (28 + allTexts.size * 4 + (cur - styleData.size)).toLong() else 0L)
            var o = 28
            for (off in offsets) {
                wU32(newPool, o, off.toLong())
                o += 4
            }
            for (d in datas) {
                System.arraycopy(d, 0, newPool, o, d.size)
                o += align4(d.size)
            }
            if (styleData != null) System.arraycopy(styleData, 0, newPool, o, styleData.size)
        }
        val poolEnd = poolPos + poolLen
        val ATTR_ID = 16842782L
        var newMap: ByteArray? = null
        var mapMode = 0
        if (mapPos < 0) {
            mapMode = 1
            val nm = ByteArray(8 + 4 * (soIdx + 1))
            wU16(nm, 0, 384)
            wU16(nm, 2, 8)
            wU32(nm, 4, nm.size.toLong())
            for (i in 0 until soIdx) wU32(nm, 8 + i * 4, 0)
            wU32(nm, 8 + soIdx * 4, ATTR_ID)
            newMap = nm
        } else {
            val entries = (mapLen - 8) / 4
            if (entries >= soIdx + 1) {
                val out2 = xml.copyOf()
                wU32(out2, mapPos + 8 + soIdx * 4, ATTR_ID)
                xml = out2
                mapMode = 0
            } else {
                mapMode = 2
                val nm = ByteArray(8 + 4 * (soIdx + 1))
                System.arraycopy(xml, mapPos, nm, 0, mapLen)
                wU16(nm, 0, 384)
                wU16(nm, 2, 8)
                wU32(nm, 4, nm.size.toLong())
                for (i in entries until soIdx) wU32(nm, 8 + i * 4, 0)
                wU32(nm, 8 + soIdx * 4, ATTR_ID)
                newMap = nm
            }
        }
        var actOff = -1
        run {
            val pos = if (mapPos >= 0) mapPos + mapLen else poolEnd
            var p = pos
            while (p + 8 <= xml.size) {
                if (rU16(xml, p) == 258 && rU32(xml, p + 20) == actIdx.toLong()) {
                    actOff = p
                    break
                }
                p += 4
            }
        }
        if (actOff < 0) return xml
        val attrStart = rU16(xml, actOff + 24)
        val attrSize = rU16(xml, actOff + 26)
        val attrCount = rU32(xml, actOff + 28).toInt()
        if (attrStart != 20 || attrSize != 20) return xml
        val elemLen = 16 + attrStart + attrCount * attrSize
        val elem = xml.copyOfRange(actOff, actOff + elemLen)
        val newElem = ByteArray(elemLen + 20)
        System.arraycopy(elem, 0, newElem, 0, elem.size)
        wU32(newElem, 4, newElem.size.toLong())
        wU32(newElem, 28, (attrCount + 1).toLong())
        val q0 = 16 + attrStart + attrCount * attrSize
        wU32(newElem, q0, nsIdx.toLong())
        wU32(newElem, q0 + 4, soIdx.toLong())
        wU32(newElem, q0 + 8, 4294967295L)
        wU16(newElem, q0 + 12, 8)
        newElem[q0 + 14] = 0
        newElem[q0 + 15] = 16
        wU32(newElem, q0 + 16, v.toLong())
        val pre = xml.copyOfRange(0, poolPos)
        val tail = xml.copyOfRange(actOff + elemLen, xml.size)
        val mid: ByteArray = if (mapMode == 0) {
            xml.copyOfRange(poolPos + poolLen, actOff)
        } else {
            val beforeMap = if (mapPos < 0) xml.copyOfRange(poolPos + poolLen, actOff) else xml.copyOfRange(poolPos + poolLen, mapPos)
            val afterMap = if (mapPos < 0) ByteArray(0) else xml.copyOfRange(mapPos + mapLen, actOff)
            concat(listOf(beforeMap, newMap!!, afterMap))
        }
        val out = ByteArray(pre.size + newPool.size + mid.size + newElem.size + tail.size)
        System.arraycopy(pre, 0, out, 0, pre.size)
        System.arraycopy(newPool, 0, out, pre.size, newPool.size)
        System.arraycopy(mid, 0, out, pre.size + newPool.size, mid.size)
        var q = pre.size + newPool.size + mid.size
        System.arraycopy(newElem, 0, out, q, newElem.size)
        q += newElem.size
        System.arraycopy(tail, 0, out, q, tail.size)
        wU32(out, 4, out.size.toLong())
        return out
    }

    private val CRC_TABLE: IntArray = IntArray(256).also { t ->
        val poly = 0xEDB88320L.toInt()
        for (i in 0..255) {
            var c = i
            repeat(8) {
                c = if (c and 1 != 0) (c ushr 1) xor poly else c ushr 1
            }
            t[i] = c
        }
    }

    private fun crc32(bytes: ByteArray): Long {
        var c = -1
        for (b in bytes) c = (c ushr 8) xor CRC_TABLE[(c xor b.toInt()) and 0xFF]
        return c.inv().toLong() and 0xFFFFFFFFL
    }

    private fun deflateRaw(data: ByteArray): ByteArray? {
        return try {
            val d = Deflater(Deflater.DEFAULT_COMPRESSION, true)
            d.setInput(data)
            d.finish()
            val buf = ByteArray(data.size + 128)
            var n = 0
            while (!d.finished()) {
                val w = d.deflate(buf, n, buf.size - n)
                if (w == 0) break
                n += w
            }
            d.end()
            buf.copyOf(n)
        } catch (e: Exception) {
            null
        }
    }

    private fun sha1B64(data: ByteArray): String {
        val d = MessageDigest.getInstance("SHA-1").digest(data)
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    private fun buildJarSignature(entries: List<ApkEntry>, apkSignedAttr: String?): Pair<ByteArray, ByteArray> {
        var mf = "Manifest-Version: 1.0\r\nCreated-By: 1.0 (WebAPK Builder)\r\n\r\n"
        for (e in entries) mf += "Name: " + e.name + "\r\nSHA1-Digest: " + sha1B64(e.data) + "\r\n\r\n"
        val mfBytes = mf.toByteArray(Charsets.UTF_8)
        val mainEnd = mf.indexOf("\r\n\r\n") + 4
        val mainAttrDigest = sha1B64(mfBytes.copyOfRange(0, mainEnd))
        var sf = "Signature-Version: 1.0\r\nCreated-By: 1.0 (WebAPK Builder)\r\n"
        if (apkSignedAttr != null) sf += "X-Android-APK-Signed: " + apkSignedAttr + "\r\n"
        sf += "SHA1-Digest-Manifest: " + sha1B64(mfBytes) + "\r\n"
        sf += "SHA1-Digest-Manifest-Main-Attributes: " + mainAttrDigest + "\r\n\r\n"
        var idx = mainEnd
        for (e in entries) {
            val secStart = idx
            val line = "SHA1-Digest: "
            val secLen = ("Name: " + e.name + "\r\n" + line).length + 28 + 2 + 2
            val secDigest = sha1B64(mfBytes.copyOfRange(secStart, secStart + secLen))
            sf += "Name: " + e.name + "\r\n" + line + secDigest + "\r\n\r\n"
            idx += secLen
        }
        return Pair(mfBytes, sf.toByteArray(Charsets.UTF_8))
    }

    private fun derLen(n: Int): ByteArray {
        if (n < 128) return byteArrayOf(n.toByte())
        val bytes = mutableListOf<Int>()
        var v = n
        while (v > 0) {
            bytes.add(0, v and 0xFF)
            v = v shr 8
        }
        val out = ByteArray(1 + bytes.size)
        out[0] = (0x80 or bytes.size).toByte()
        for (i in bytes.indices) out[i + 1] = bytes[i].toByte()
        return out
    }

    private fun tlv(tag: Int, content: ByteArray): ByteArray =
        concat(listOf(byteArrayOf(tag.toByte()), derLen(content.size), content))

    private fun derNull(): ByteArray = tlv(0x05, ByteArray(0))

    private fun oidBytes(hex: String): ByteArray {
        val out = ByteArray(hex.length / 2)
        for (i in out.indices) out[i] = hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return out
    }

    private fun algId(oidHex: String): ByteArray = tlv(0x30, concat(listOf(oidBytes(oidHex), derNull())))

    private fun buildPkcs7(sfBytes: ByteArray, certDer: ByteArray, issuerDer: ByteArray, serialTlv: ByteArray, signature: ByteArray): ByteArray {
        val contentInfo = tlv(0x30, oidBytes("2a864886f70d010701"))
        val digestAlg = tlv(0x31, algId("2b0e03021a"))
        val certificates = tlv(0xA0, certDer)
        val issuerAndSerial = tlv(0x30, concat(listOf(issuerDer, serialTlv)))
        val signerInfo = tlv(
            0x30,
            concat(
                listOf(
                    tlv(0x02, byteArrayOf(1)),
                    issuerAndSerial,
                    algId("2b0e03021a"),
                    algId("2a864886f70d010101"),
                    tlv(0x04, signature)
                )
            )
        )
        val signerInfos = tlv(0x31, signerInfo)
        val signedData = tlv(
            0x30,
            concat(
                listOf(
                    tlv(0x02, byteArrayOf(1)),
                    digestAlg,
                    contentInfo,
                    certificates,
                    signerInfos
                )
            )
        )
        return tlv(0x30, concat(listOf(oidBytes("2a864886f70d010702"), tlv(0xA0, signedData))))
    }

    private fun buildZipParts(entries: List<ApkEntry>): ByteArray {
        val now = Calendar.getInstance()
        val time = ((now.get(Calendar.HOUR_OF_DAY) and 31) shl 11) or
            ((now.get(Calendar.MINUTE) and 63) shl 5) or
            ((now.get(Calendar.SECOND) / 2) and 31)
        val date = (((now.get(Calendar.YEAR) - 1980) and 127) shl 9) or
            (((now.get(Calendar.MONTH) + 1) and 15) shl 5) or
            (now.get(Calendar.DAY_OF_MONTH) and 31)
        val locals = mutableListOf<ByteArray>()
        val centrals = mutableListOf<ByteArray>()
        var offset = 0L
        for (e in entries) {
            val nb = e.name.toByteArray(Charsets.UTF_8)
            val stored = e.method != 8
            val payload = if (stored) e.data else (e.payload ?: e.data)
            val crc = crc32(e.data)
            val headerLen = 30 + nb.size
            var pad = 0
            if (stored && e.align > 0) {
                val r = ((offset + headerLen) % e.align).toInt()
                if (r != 0) pad = e.align - r
            }
            var extra = ByteArray(0)
            if (pad > 0) {
                val contentLen = if (pad >= 4) pad - 4 else pad
                val ex = ByteArray(4 + contentLen)
                wU16(ex, 0, 55605)
                wU16(ex, 2, contentLen)
                extra = ex
            }
            val csize = payload.size
            val usize = e.data.size
            val local = concat(
                listOf(
                    u32b(67324752L), u16b(20), u16b(2048), u16b(if (stored) 0 else 8),
                    u16b(time), u16b(date), u32b(crc),
                    u32b(if (stored) usize.toLong() else csize.toLong()), u32b(usize.toLong()),
                    u16b(nb.size), u16b(extra.size), nb, extra, payload
                )
            )
            locals.add(local)
            centrals.add(
                concat(
                    listOf(
                        u32b(33639248L), u16b(20), u16b(20), u16b(2048), u16b(if (stored) 0 else 8),
                        u16b(time), u16b(date), u32b(crc),
                        u32b(if (stored) usize.toLong() else csize.toLong()), u32b(usize.toLong()),
                        u16b(nb.size), u16b(extra.size), u16b(0), u16b(0), u16b(0), u32b(0), u32b(offset),
                        nb, extra
                    )
                )
            )
            offset += local.size
        }
        val cd = concat(centrals)
        val eocd = concat(
            listOf(
                u32b(101010256L), u16b(0), u16b(0), u16b(entries.size), u16b(entries.size),
                u32b(cd.size.toLong()), u32b(offset), u16b(0)
            )
        )
        return concat(listOf(concat(locals), cd, eocd))
    }

    fun buildApkEntries(htmlText: ByteArray, opts: ApkOptions): List<ApkEntry> {
        var manifest = T[if (opts.fullscreen) "manifest_fs" else "manifest_normal"]!!
        manifest = patchBinaryXml(manifest, listOf(DEFAULT_LABEL to opts.label, DEFAULT_PKG to opts.pkg))
        if (opts.versionName != "1.0") manifest = patchBinaryXml(manifest, listOf("1.0" to opts.versionName))
        if (opts.versionCode != 1) manifest = patchManifestVersionCode(manifest, opts.versionCode)
        if (opts.permissions.isNotEmpty()) manifest = addManifestPermissions(manifest, opts.permissions)
        if (opts.orientation >= 0) manifest = addScreenOrientation(manifest, opts.orientation)
        var arsc = T["resources.arsc"]!!
        if (opts.pkg != DEFAULT_PKG) arsc = patchArscPackageName(arsc, DEFAULT_PKG, opts.pkg)
        val dex = when {
            opts.fullscreen && opts.deep == "plain" -> T["classes_plain_fs.dex"]!!
            opts.fullscreen && opts.deep == "adv" -> T["classes_adv_fs.dex"]!!
            opts.fullscreen -> T["classes_fs.dex"]!!
            opts.deep == "plain" -> T["classes_plain.dex"]!!
            opts.deep == "adv" -> T["classes_adv.dex"]!!
            else -> T["classes_normal.dex"]!!
        }
        val icon = opts.icon ?: T["icon.png"]!!
        return listOf(
            ApkEntry("AndroidManifest.xml", manifest, 0, 4),
            ApkEntry("resources.arsc", arsc, 0, 4),
            ApkEntry("classes.dex", dex, 8),
            ApkEntry("assets/index.html", htmlText, 8),
            ApkEntry("assets/ux.js", T["ux.js"]!!, 8),
            ApkEntry("res/mipmap/ic_launcher.png", icon, 0, 4)
        )
    }

    fun generateApk(htmlText: ByteArray, opts: ApkOptions): ByteArray {
        val entries = buildApkEntries(htmlText, opts).toMutableList()
        for (e in entries) {
            if (e.method != 8) continue
            val c = deflateRaw(e.data)
            if (c != null) e.payload = c else e.method = 0
        }
        val jar = buildJarSignature(entries, null)
        val sfBytes = jar.second
        val kf = KeyFactory.getInstance("RSA")
        val key: PrivateKey = kf.generatePrivate(PKCS8EncodedKeySpec(T["key.pkcs8"]!!))
        val sig = Signature.getInstance("SHA1withRSA")
        sig.initSign(key)
        sig.update(sfBytes)
        val signature = sig.sign()
        val pkcs7 = buildPkcs7(sfBytes, T["cert.der"]!!, T["issuer.der"]!!, T["serial.der"]!!, signature)
        val out = entries.toMutableList()
        out.add(ApkEntry("META-INF/MANIFEST.MF", jar.first, 0, 4))
        out.add(ApkEntry("META-INF/CERT.SF", sfBytes, 0, 4))
        out.add(ApkEntry("META-INF/CERT.RSA", pkcs7, 0, 4))
        return buildZipParts(out)
    }
}
