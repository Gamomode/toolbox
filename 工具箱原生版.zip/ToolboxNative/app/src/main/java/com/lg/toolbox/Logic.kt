package com.lg.toolbox

import android.util.Base64
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Logic {

    fun digestHex(alg: String, text: String): String {
        val md = MessageDigest.getInstance(alg)
        val bytes = md.digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun pbkdf2Hex(password: String, salt: String, algo: String, iterations: Int = 100000): String {
        val bits = when (algo) {
            "SHA-512" -> 512
            "SHA-384" -> 384
            "SHA-1" -> 160
            else -> 256
        }
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmac$algo")
        val spec = PBEKeySpec(password.toCharArray(), salt.toByteArray(Charsets.UTF_8), iterations, bits)
        val key = factory.generateSecret(spec).encoded
        return key.joinToString("") { "%02x".format(it) }
    }

    fun hexToBase64(hex: String): String? {
        if (hex.length % 2 != 0) return null
        return try {
            val bytes = ByteArray(hex.length / 2)
            for (i in bytes.indices) bytes[i] = hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    fun toEntityGarbled(text: String): String =
        text.map { "&#x" + it.code.toString(16) + ";" }.joinToString("")

    fun toScriptGarbled(text: String): String {
        val b64 = Base64.encodeToString(text.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val rev = b64.reversed()
        val a = rev.substring(0, rev.length / 3)
        val b = rev.substring(rev.length / 3, rev.length * 2 / 3)
        val c = rev.substring(rev.length * 2 / 3)
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Obfuscated App</title>
</head>
<body>
<script>
(function(){var _a="$b",_b="$a",_c="$c";var _res="",_s=0,_arr=[_a,_b,_c];while(true){if(_s===0){_res+=_arr[1];_s=2;}else if(_s===2){_res+=_arr[0];_s=1;}else if(_s===1){_res+=_arr[2];_s=3;}else if(_s===3){var _x=_res.split("").reverse().join("");var _y=decodeURIComponent(escape(atob(_x)));var _f=document.createElement("iframe");_f.style.cssText="width:100%;height:100vh;border:none;";_f.srcdoc=_y;document.body.innerHTML="";document.body.appendChild(_f);break;}}})();
</script>
</body>
</html>"""
    }

    fun fromGarbled(text: String): String? {
        return try {
            val div = "<div>$text</div>"
            val start = div.indexOf(">") + 1
            val end = div.lastIndexOf("<")
            val decoded = android.text.Html.fromHtml(div, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
            if (decoded.isBlank() || decoded.contains("document.write") || decoded.contains("while(true)")) null else decoded
        } catch (e: Exception) {
            null
        }
    }

    private fun keyStream(password: String, len: Int): IntArray {
        var seed = 2166136261L
        for (ch in password) {
            seed = seed xor ch.code.toLong()
            seed = (seed * 16777619L) and 0xFFFFFFFFL
        }
        var state = if (seed == 0L) 1L else seed
        val out = IntArray(len)
        for (i in 0 until len) {
            state = state xor (state shl 13) and 0xFFFFFFFFL
            state = state xor (state ushr 17)
            state = state xor (state shl 5) and 0xFFFFFFFFL
            out[i] = (state and 0xFF).toInt()
        }
        return out
    }

    fun buildEncryptedPage(content: String, password: String?): String {
        val plain = "#SEC#" + content
        val bytes = plain.toByteArray(Charsets.UTF_8)
        val pw = if (password.isNullOrBlank()) "" else password
        val ks = keyStream(pw, bytes.size)
        val hex = bytes.mapIndexed { i, b -> ((b.toInt() and 0xFF) xor ks[i]).toString(16).padStart(2, "0") }.joinToString("")
        val lockHtml = if (pw.isEmpty()) "" else """
<div class="_lock" id="_lock">
  <h2>本页已加密</h2>
  <input type="password" id="_p" placeholder="输入访问密码" autocomplete="off">
  <button id="_b">解锁查看</button>
  <p id="_e"></p>
</div>
"""
        val unlockJs = if (pw.isEmpty()) """
(function(){
  var text;
  try{text=_dec(_0xd,'');}catch(e){document.write('<p style="font-family:sans-serif;padding:24px">页面内容损坏</p>');return;}
  if(text.indexOf('#SEC#')!==0){document.write('<p style="font-family:sans-serif;padding:24px">页面内容损坏</p>');return;}
  _rw(text.substring(5));
})();""" else """
(function(){
  var inp=document.getElementById('_p'),btn=document.getElementById('_b'),err=document.getElementById('_e');
  function unlock(){
    var pw=inp.value;
    if(!pw){err.textContent='请输入密码';return;}
    var text;
    try{text=_dec(_0xd,pw);}catch(e){err.textContent='解密失败';return;}
    if(text.indexOf('#SEC#')!==0){err.textContent='密码错误，请重试';return;}
    _rw(text.substring(5));
  }
  btn.addEventListener('click',unlock);
  inp.addEventListener('keydown',function(e){if(e.key==='Enter'||e.keyCode===13)unlock();});
  inp.focus();
})();"""
        return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>本页已加密</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;min-height:100%;}
body{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;background:linear-gradient(135deg,#0f172a,#1e293b,#0f172a);color:#e8eaf6;padding:20px}
._lock{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:20px;padding:34px 28px;max-width:340px;width:100%;text-align:center}
._lock h2{margin:0 0 18px;font-size:20px}
._lock input{width:100%;min-height:48px;padding:10px 14px;border:1px solid rgba(255,255,255,0.18);border-radius:12px;font-size:15px;background:rgba(0,0,0,0.3);color:#fff;outline:none}
._lock button{width:100%;min-height:48px;margin-top:14px;border:none;border-radius:12px;background:linear-gradient(135deg,#6366f1,#22d3ee);color:#fff;font-size:16px;font-weight:600;cursor:pointer}
._lock p{color:#f87171;font-size:14px;min-height:1.4em;margin:10px 0 0}
</style>
</head>
<body>
$lockHtml<script>
var _0xd="$hex";
function _ks(p,n){var s=2166136261,i;for(i=0;i<p.length;i++){s^=p.charCodeAt(i);s=Math.imul(s,16777619)>>>0;}var st=s||1,o=new Uint8Array(n);for(i=0;i<n;i++){st^=(st<<13);st>>>=0;st^=(st>>>17);st^=(st<<5);st>>>=0;o[i]=st&0xff;}return o;}
function _dec(h,p){var n=h.length/2,i,b=new Uint8Array(n);for(i=0;i<n;i++)b[i]=parseInt(h.substr(i*2,2),16);var k=_ks(p,n),o=new Uint8Array(n);for(i=0;i<n;i++)o[i]=b[i]^k[i];return new TextDecoder().decode(o);}
function _rw(real){
    document.open();
    if(/<[a-zA-Z]+[\s>]|<html|<body|<script|<style|<h1|<div/.test(real)){
        document.write(real);
    }else{
        var safe = real.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;padding:28px;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;font-size:17px;line-height:1.9;white-space:pre-wrap;word-break:break-word;background:linear-gradient(160deg,#0f1220,#151a2e);color:#e8eaf6;min-height:100vh;box-sizing:border-box}</style></head><body>'+safe+'</body></html>');
    }
    document.close();
}
$unlockJs
</script>
</body>
</html>"""
    }
}
