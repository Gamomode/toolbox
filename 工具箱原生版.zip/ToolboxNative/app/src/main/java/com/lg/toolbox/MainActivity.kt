package com.lg.toolbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ThemeSpec(
    val name: String,
    val bg: Color,
    val panel: Color,
    val ink: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val line: Color
)

val THEMES = listOf(
    ThemeSpec("teal", Color(0xFFEAF7F4), Color(0xFFFFFFFF), Color(0xFF12312B), Color(0xFF5C7A73), Color(0xFF0E9F8A), Color(0xFFD7F2EC), Color(0xFFD8E8E4)),
    ThemeSpec("sky", Color(0xFFEAF3FB), Color(0xFFFFFFFF), Color(0xFF12283A), Color(0xFF5A7186), Color(0xFF2B7FD4), Color(0xFFD9EAF8), Color(0xFFD6E4F0)),
    ThemeSpec("violet", Color(0xFFF3EFFB), Color(0xFFFFFFFF), Color(0xFF241A3E), Color(0xFF6B5F8A), Color(0xFF6D4FD0), Color(0xFFE6DFF9), Color(0xFFE0DAF0)),
    ThemeSpec("rose", Color(0xFFFBEEF1), Color(0xFFFFFFFF), Color(0xFF3A1220), Color(0xFF8A5A6B), Color(0xFFD4436E), Color(0xFFF9DCE4), Color(0xFFF0DAE0)),
    ThemeSpec("amber", Color(0xFFFBF3E4), Color(0xFFFFFFFF), Color(0xFF3A2A10), Color(0xFF8A7350), Color(0xFFD08A1F), Color(0xFFF8EAD0), Color(0xFFF0E4CC)),
    ThemeSpec("night", Color(0xFF0F172A), Color(0xFF1B2740), Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF38BDF8), Color(0xFF23324D), Color(0xFF2C3B5C))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            ToolboxApp(store)
        }
    }
}

@Composable
fun ToolboxApp(store: Store) {
    var themeIdx by remember { mutableStateOf(store.themeIndex()) }
    val th = THEMES[themeIdx.coerceIn(0, THEMES.size - 1)]
    var screen by remember { mutableStateOf("home") }
    var userTick by remember { mutableStateOf(0) }
    var toast by remember { mutableStateOf<String?>(null) }
    var showAuth by remember { mutableStateOf(false) }
    var showShop by remember { mutableStateOf(false) }
    var showTasks by remember { mutableStateOf(false) }
    var showPremium by remember { mutableStateOf(false) }
    var drawerOpen by remember { mutableStateOf(false) }

    val tick = userTick

    fun notify(msg: String) { toast = msg }

    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(2200)
            toast = null
        }
    }

    val ctx = LocalContext.current

    Box(
        Modifier
            .fillMaxSize()
            .background(th.bg)
    ) {
        Column(Modifier.fillMaxSize()) {
            Surface(color = th.panel, shadowElevation = 2.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("☰", fontSize = 22.sp, color = th.ink, modifier = Modifier.clickable { drawerOpen = true })
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("工具箱", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = th.ink)
                        Text(
                            when (screen) {
                                "hash" -> "浏览器原生支持的标准摘要算法"
                                "salt" -> "10 万次迭代，显著提高破解成本"
                                "convert" -> "把十六进制字符串转换为 Base64"
                                "encrypt" -> "生成带密码锁的网页，本地完成加密"
                                "garbled" -> "实体编码 / 不可逆 JS 混淆"
                                "tutorial" -> "查看工具箱使用说明"
                                else -> "原生版 · 全部本地运行"
                            },
                            fontSize = 11.sp, color = th.muted
                        )
                    }
                    Text(
                        store.maskedUser(),
                        fontSize = 13.sp,
                        color = th.accent,
                        modifier = Modifier
                            .clickable { if (store.currentUser == null) showAuth = true }
                            .padding(6.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "$" + "%.2f".format(store.balance()),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = th.accent,
                        modifier = Modifier
                            .background(th.accentSoft, RoundedCornerShape(999.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Box(Modifier.weight(1f)) {
                when (screen) {
                    "hash" -> ToolScreen(th, store, ToolKind.HASH) { notify(it) }
                    "salt" -> ToolScreen(th, store, ToolKind.SALT) { notify(it) }
                    "convert" -> ToolScreen(th, store, ToolKind.CONVERT) { notify(it) }
                    "encrypt" -> ToolScreen(th, store, ToolKind.ENCRYPT) { notify(it) }
                    "garbled" -> ToolScreen(th, store, ToolKind.GARBLED) { notify(it) }
                    "tutorial" -> TutorialScreen(th)
                    else -> HomeScreen(th, store, onOpen = { screen = it }, onPremium = { showPremium = true })
                }
            }

            Surface(color = th.panel, shadowElevation = 8.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BottomBtn("任务", th, Modifier.weight(1f)) { showTasks = true }
                    BottomBtn("商店", th, Modifier.weight(1f)) { showShop = true }
                    BottomBtn("高级版", th, Modifier.weight(1f), gold = true) { showPremium = true }
                    BottomBtn(if (store.currentUser == null) "登录" else "退出", th, Modifier.weight(1f)) {
                        if (store.currentUser == null) showAuth = true else {
                            store.logout()
                            userTick++
                            notify("已退出登录")
                        }
                    }
                }
            }
        }

        if (drawerOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .clickable { drawerOpen = false }
            )
            Surface(
                color = th.panel,
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.84f)
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Spacer(Modifier.height(24.dp))
                    Text("工具箱", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = th.ink)
                    Text("原生版 v1.0", fontSize = 12.sp, color = th.muted)
                    Spacer(Modifier.height(18.dp))
                    DrawerItem("🏠 首页", th) { screen = "home"; drawerOpen = false }
                    DrawerItem("🔐 基础哈希计算", th) { screen = "hash"; drawerOpen = false }
                    DrawerItem("🔄 格式转换", th) { screen = "convert"; drawerOpen = false }
                    DrawerItem("🔒 加密网页", th) { screen = "encrypt"; drawerOpen = false }
                    DrawerItem("🧂 加盐慢哈希", th) { screen = "salt"; drawerOpen = false }
                    DrawerItem("🌀 HTML 转乱码", th) { screen = "garbled"; drawerOpen = false }
                    DrawerItem("📖 新手教程", th) { screen = "tutorial"; drawerOpen = false }
                    Spacer(Modifier.height(18.dp))
                    Text("主题", fontSize = 13.sp, color = th.muted)
                    Spacer(Modifier.height(8.dp))
                    Row {
                        THEMES.forEachIndexed { i, t ->
                            Box(
                                Modifier
                                    .padding(end = 10.dp)
                                    .size(30.dp)
                                    .background(t.accent, CircleShape)
                                    .border(
                                        width = if (i == themeIdx) 3.dp else 1.dp,
                                        color = if (i == themeIdx) th.ink else th.line,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        themeIdx = i
                                        store.setThemeIndex(i)
                                    }
                            )
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(
                        "生效时间：2026年11月21日\n结束时间：长期有效",
                        fontSize = 11.sp,
                        color = th.muted
                    )
                }
            }
        }

        if (showAuth) {
            AuthDialog(th, store, onClose = { showAuth = false }, onDone = {
                showAuth = false
                userTick++
                notify(it)
            })
        }
        if (showShop) {
            ShopDialog(th, store, onClose = { showShop = false }, notify = { notify(it); userTick++ })
        }
        if (showTasks) {
            TasksDialog(th, store, onClose = { showTasks = false }, notify = { notify(it); userTick++ })
        }
        if (showPremium) {
            PremiumDialog(th, store, onClose = { showPremium = false }, notify = { notify(it) })
        }

        toast?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 90.dp)
                    .background(Color(0xFF141923).copy(alpha = 0.92f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(msg, color = Color.White, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun BottomBtn(label: String, th: ThemeSpec, modifier: Modifier = Modifier, gold: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier
            .padding(horizontal = 4.dp)
            .background(
                if (gold) Brush.horizontalGradient(listOf(Color(0xFFFBBF24), Color(0xFFD97706))) else Brush.horizontalGradient(listOf(th.accentSoft, th.accentSoft)),
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (gold) Color(0xFF3A2A10) else th.accent)
    }
}

@Composable
fun DrawerItem(label: String, th: ThemeSpec, onClick: () -> Unit) {
    Text(
        label,
        fontSize = 15.sp,
        color = th.ink,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp)
    )
}

@Composable
fun HomeScreen(th: ThemeSpec, store: Store, onOpen: (String) -> Unit, onPremium: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(th.accent, th.accent.copy(alpha = 0.7f))), RoundedCornerShape(18.dp))
                .padding(20.dp)
        ) {
            Column {
                Text("工具箱 · 原生版", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Text("Kotlin 原生实现，不依赖 WebView，老手机也流畅", fontSize = 13.sp, color = Color.White.copy(alpha = 0.9f))
            }
        }
        Spacer(Modifier.height(16.dp))
        val eff = store.effectiveLevel()
        Text("当前身份：${eff.label}", fontSize = 14.sp, color = th.muted)
        Spacer(Modifier.height(10.dp))
        FeatureCard("🔐", "基础哈希计算", "MD5 / SHA-1 / SHA-256 等，本地秒算", th) { onOpen("hash") }
        FeatureCard("🔄", "格式转换", "十六进制字符串转 Base64", th) { onOpen("convert") }
        FeatureCard("🔒", "加密网页", "生成带密码锁的网页文件", th) { onOpen("encrypt") }
        FeatureCard("🧂", "加盐慢哈希", "PBKDF2 十万次迭代", th) { onOpen("salt") }
        FeatureCard("🌀", "HTML 转乱码", "实体编码 / 不可逆 JS 混淆", th) { onOpen("garbled") }
        FeatureCard("📖", "新手教程", "查看使用说明", th) { onOpen("tutorial") }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Color(0xFFFBBF24), Color(0xFFD97706))), RoundedCornerShape(16.dp))
                .clickable { onPremium() }
                .padding(18.dp)
        ) {
            Column {
                Text("👑 高级版", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3A2A10))
                Spacer(Modifier.height(2.dp))
                Text("工具箱 · 新手教程", fontSize = 12.sp, color = Color(0xFF6B5210))
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun FeatureCard(icon: String, title: String, sub: String, th: ThemeSpec, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(th.panel, RoundedCornerShape(16.dp))
            .border(1.dp, th.line, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = th.ink)
                Text(sub, fontSize = 12.sp, color = th.muted)
            }
        }
    }
}

@Composable
fun AuthDialog(th: ThemeSpec, store: Store, onClose: () -> Unit, onDone: (String) -> Unit) {
    var isLogin by remember { mutableStateOf(true) }
    var phone by remember { mutableStateOf("") }
    var pwd by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = th.panel,
        title = { Text(if (isLogin) "登录" else "注册账号", color = th.ink, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("手机号") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pwd,
                    onValueChange = { pwd = it },
                    label = { Text("密码（至少 6 位）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                err?.let {
                    Text(it, color = Color(0xFFE5484D), fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    if (isLogin) "还没有账号？去注册" else "已有账号？去登录",
                    fontSize = 13.sp,
                    color = th.accent,
                    modifier = Modifier
                        .clickable { isLogin = !isLogin; err = null }
                        .padding(vertical = 6.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = if (isLogin) store.login(phone.trim(), pwd.trim()) else store.register(phone.trim(), pwd.trim())
                if (e != null) err = e
                else onDone(if (isLogin) "登录成功" else "注册成功，已自动登录")
            }) { Text(if (isLogin) "登 录" else "注 册", color = th.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("取消", color = th.muted) }
        }
    )
}

@Composable
fun TutorialScreen(th: ThemeSpec) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        TutorialSection("欢迎使用工具箱原生版", "这一版用 Kotlin 原生编写，界面和计算全部在手机本地完成，不依赖手机系统 WebView 内核，不同机型表现一致。", th)
        TutorialSection("基础哈希计算", "输入任意文字，选择 MD5、SHA-1、SHA-256 等算法，点计算即可得到摘要。每次计算会自动记入每日任务。", th)
        TutorialSection("格式转换", "把十六进制字符串粘贴进来，一键转成 Base64。转换结果可以复制或保存。", th)
        TutorialSection("加密网页", "输入要保护的网页或文字，设置访问密码，生成一个带密码锁的 HTML 文件。对方打开需要输入密码，密码错误无法查看。", th)
        TutorialSection("加盐慢哈希", "PBKDF2 算法迭代十万次，显著提高暴力破解成本，适合口令存储场景。", th)
        TutorialSection("HTML 转乱码", "实体编码模式可还原；JS 混淆模式不可逆，只是表层混淆，不能指望它保护重要代码。", th)
        TutorialSection("身份与商店", "底部「商店」可以购买各等级会员，等级越高可用工具越多；「任务」里每天签到、算哈希、做转换都能领余额。", th)
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun TutorialSection(title: String, body: String, th: ThemeSpec) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(th.panel, RoundedCornerShape(16.dp))
            .border(1.dp, th.line, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = th.ink)
            Spacer(Modifier.height(6.dp))
            Text(body, fontSize = 14.sp, color = th.muted, lineHeight = 22.sp)
        }
    }
}
